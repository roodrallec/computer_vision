% - - - - - - 
% MAI CV
% Exercises Lab 1
% Author name: Emer Rodriguez Formisano and Jorge Alexander
% - - - - - - 


%%
%- - - - - - 
%Exercise 3:
%- - - - - - 
% Using the function mirror_image
clooney = imread('images/clooney.jpg');
cut_column = 225;
imshow(mirror_image(clooney, cut_column))
