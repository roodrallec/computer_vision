% - - - - - - 
% MAI CV
% Exercises Lab 6
% Author name: Emer Rodriguez Formisano & Jorge Alexander 
% - - - - - - 
% >> OBJECTIVE: 
% 1)Complete this function to solve the subject recognition problem
% main function
function main_subject_recognition()

end




